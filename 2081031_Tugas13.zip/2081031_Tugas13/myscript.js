//Ini bagian javascript

window.alert("Ini Tugas 13");

console.log("Ini bagian console");